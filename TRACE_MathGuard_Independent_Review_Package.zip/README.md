# TRACE MathGuard V1.3.5a Independent Review Package

This package contains 45 fresh, out-of-sample holdout cases (30 negative controls across 14 defect categories, 10 positive controls, and 5 legitimate abstention cases) for independent evaluation by Gemini Neon or an external reviewer.

Run from the Triggle repository root:
```bash
PYTHONPATH=site/tools python3 run_independent_holdout.py
```
