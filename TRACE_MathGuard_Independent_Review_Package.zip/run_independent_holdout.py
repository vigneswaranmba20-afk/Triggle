"""Standalone runner for TRACE MathGuard V1.3.5a Independent Holdout Package."""
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
# Assumes repo root is parent or passed via PYTHONPATH=site/tools
if (HERE / "site" / "tools").exists():
    sys.path.insert(0, str(HERE / "site" / "tools"))

from mathguard.reasoning_engine import verify_complete_working

def main():
    cases = json.loads((HERE / "holdout_items.json").read_text(encoding="utf-8"))
    fa = fr = abst = det = passed = 0
    for c in cases:
        res = verify_complete_working(c["item"], is_concept=False, allow_positive_domain=c["allow_positive_domain"])
        obs = res.status
        exp = c["expected_outcome"]
        if exp == "PASS":
            ok = obs == "PASS"
            if not ok: fr += 1
        elif exp == "FAIL":
            ok = obs == "FAIL"
            if obs == "FAIL": det += 1
            elif obs == "PASS": fa += 1
            else: abst += 1
        else:
            ok = obs in ("PARTIAL", "UNVERIFIABLE")
            if obs == "PASS": fa += 1
            elif obs == "FAIL": fr += 1
            else: abst += 1
        if ok: passed += 1
    print(json.dumps({"total": len(cases), "passed": passed, "confirmedDetections": det, "falseAcceptances": fa, "falseRejections": fr, "abstentions": abst}, indent=2))

if __name__ == "__main__":
    main()
