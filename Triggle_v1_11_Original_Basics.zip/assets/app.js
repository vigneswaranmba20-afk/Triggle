(()=>{'use strict';
 const $=id=>document.getElementById(id);
 const tr=x=>x && typeof x==='object' ? (x[lang]||x.en||'') : String(x||'');
 const dictionary={
 en:{yourClass:'YOUR CLASS',exploreExercise:'Find an exercise',saveNote:'Your progress stays on this device',openBasics:'Interactive basics',browse:'Exercises',basics:'Basics',studyMode:'YOUR LEARNING SPACE',diagram:'Diagram',stepByStep:'STEP-BY-STEP SOLUTION',finalAnswer:'Final answer',markDone:'Mark learned',learned:'Learned',previous:'Previous',nextQuestion:'Next question',source:'Reference ↗',classic:'Original Class 9 interface',visualGuide:'VISUAL EXPLANATION',close:'Close',typeBook:'Book-referenced · edition check',typePractice:'Original Triggle practice',class:'Class',search:'Search exercise, question...',subtitle:'Choose a topic, understand every step, go at your own pace.',nextStep:'Next step',showAll:'Show full solution',answer:'Show final answer',complete:'Solution complete',empty:'No lessons match your search.',noteBook:'Textbook question references were cross-checked against public listings. Editions can differ; compare with your prescribed book.',noteOld:'Class 9 exercises reference an earlier textbook edition. Verify numbering against your school copy.',notePractice:'Original Triggle practice — not a numbered textbook question.',lessons:'lessons',question:'Question',practice:'Practice',reference:'Reference',step:'Step',of:'of'},
 ta:{yourClass:'உங்கள் வகுப்பு',exploreExercise:'பயிற்சியைத் தேடுங்கள்',saveNote:'உங்கள் முன்னேற்றம் இந்த சாதனத்தில் மட்டும் சேமிக்கப்படும்',openBasics:'காட்சி அடிப்படைகள்',browse:'பயிற்சிகள்',basics:'அடிப்படைகள்',studyMode:'கற்றல் பகுதி',diagram:'படம்',stepByStep:'படிப்படியான தீர்வு',finalAnswer:'இறுதி விடை',markDone:'கற்றதாகக் குறி',learned:'கற்றுவிட்டேன்',previous:'முந்தையது',nextQuestion:'அடுத்த கேள்வி',source:'குறிப்பு ↗',classic:'வகுப்பு 9 பழைய தோற்றம்',visualGuide:'காட்சி விளக்கம்',close:'மூடு',typeBook:'பாடநூல் குறிப்பு · பதிப்பு சரிபார்க்கவும்',typePractice:'டிரிகிள் உருவாக்கிய பயிற்சி',class:'வகுப்பு',search:'பயிற்சி, கேள்வியைத் தேட...',subtitle:'ஒரு தலைப்பைத் தேர்ந்தெடுத்து படிப்படியாக எளிதில் கற்றுக்கொள்ளுங்கள்.',nextStep:'அடுத்த படி',showAll:'முழுத் தீர்வைக் காட்டு',answer:'இறுதி விடையைக் காட்டு',complete:'தீர்வு முடிந்தது',empty:'இந்தத் தேடலுக்கான பாடங்கள் இல்லை.',noteBook:'பொது பட்டியலில் பாடநூல் வினா விவரங்கள் சரிபார்க்கப்பட்டன. உங்கள் பள்ளிப் புத்தகப் பதிப்புடன் ஒப்பிடுங்கள்.',noteOld:'வகுப்பு 9 பயிற்சிகள் முந்தைய பாடநூல் பதிப்பைச் சார்ந்தவை. உங்கள் புத்தக எண்ணிடலைச் சரிபார்க்கவும்.',notePractice:'இது டிரிகிள் உருவாக்கிய பயிற்சி; பாடநூல் வினா எண் அல்ல.',lessons:'பாடங்கள்',question:'வினா',practice:'பயிற்சி',reference:'குறிப்பு',step:'படி',of:'இல்'} };
 const ui=k=>dictionary[lang][k]||dictionary.en[k]||k;
 const classes=window.TRIGGLE_CLASSES||{};
 for(const key of [9,10,11,12]){if(!classes[key]||!Array.isArray(classes[key].items))throw Error('Missing data for class '+key);}
 const load=(key,other)=>{try{const v=JSON.parse(localStorage.getItem(key));return v===null?other:v}catch{return other}};
 const store=(key,value)=>{try{localStorage.setItem(key,JSON.stringify(value))}catch{}};
 const completed=new Set(load('triggle.learned.v119',[]));
 const lastByGrade=load('triggle.lastByGrade.v119',{});
 let lang='en';try{const saved=localStorage.getItem('triggle-language');if(saved==='ta'||saved==='"ta"')lang='ta'}catch{}
 const url=new URL(location.href), requested=Number(url.searchParams.get('class'));
 let grade=classes[requested]?requested:9;
 let current=classes[grade].items.find(x=>x.id===url.searchParams.get('question'))||classes[grade].items.find(x=>x.id===lastByGrade[grade])||classes[grade].items[0];
 let visible=1,showAnswer=false,drawerOpen=false;
 const reduced=matchMedia('(prefers-reduced-motion:reduce)');
 const mobile=matchMedia('(max-width:800px)');
 function esc(str){return String(str??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
 function math(str){
   // A small, self-contained typesetter; mathematical source strings remain text, never executable HTML.
   const tokens=[];
   const stash=tag=>{tokens.push(tag);return '\uE000M'+(tokens.length-1)+'\uE001'};
   let s=esc(str).replace(/\[\[([^\]|]+)\|([^\]]+)\]\]/g,(_m,n,d)=>stash('<span class="frac"><span>'+esc(n)+'</span><span>'+esc(d)+'</span></span>'));
   s=s.replace(/([²³⁴])/g,c=>'<sup>'+({'²':'2','³':'3','⁴':'4'}[c])+'</sup>').replace(/\^([0-9]+)/g,'<sup>$1</sup>');
   tokens.forEach((tag,i)=>s=s.replace('\uE000M'+i+'\uE001',tag));return s;
 }
 const activeList=()=>classes[grade].items;
 const currentIndex=()=>activeList().findIndex(i=>i.id===current.id);
 const num=n=>String(n).padStart(2,'0');
 const labelForGroup=(e)=>e==='6.examples'?(lang==='ta'?'எடுத்துக்காட்டுகள்':'Worked examples'):(e.includes('practice')?ui('practice')+' '+e.split('.')[0]:(e.endsWith('.unit')?'Unit Exercise '+e.split('.')[0]:(lang==='ta'?'பயிற்சி ':'Exercise ')+e));
 function updateUrl(replace=false){const u=new URL(location.href);u.searchParams.set('class',grade);u.searchParams.set('question',current.id);try{history[replace?'replaceState':'pushState']({grade,question:current.id},'',u.pathname+u.search+u.hash)}catch{}}
 function remember(){lastByGrade[grade]=current.id;store('triggle.lastByGrade.v119',lastByGrade)}
 function changeGrade(g){g=Number(g);if(!classes[g])return;grade=g;current=classes[g].items.find(x=>x.id===lastByGrade[g])||classes[g].items[0];visible=1;showAnswer=false;$('search').value='';updateUrl();remember();render();closeDrawer();(mobile.matches?document.querySelector('.workspace'):window).scrollTo({top:0,behavior:reduced.matches?'auto':'smooth'});}
 function selectLesson(item){if(item.id===current.id){closeDrawer();return;}current=item;visible=1;showAnswer=false;updateUrl();remember();render();closeDrawer();(mobile.matches?document.querySelector('.workspace'):window).scrollTo({top:0,behavior:reduced.matches?'auto':'smooth'});}
 function navMove(delta){const list=activeList(),i=currentIndex()+delta;if(i<0||i>=list.length)return;selectLesson(list[i])}
 function renderGrades(){const data=[{num:9,icon:'◈'},{num:10,icon:'◈'},{num:11,icon:'◈'},{num:12,icon:'◈'}];
  for(const type of ['side','dock']){
   const where=$(type==='side'?'sideClasses':'classDock');where.replaceChildren();
   for(const g of data){const b=document.createElement('button');b.type='button';b.className=type==='side'?'side-grade':'dock-grade';b.classList.toggle('active',grade===g.num);b.setAttribute('aria-pressed',String(grade===g.num));b.setAttribute('aria-label',ui('class')+' '+g.num);b.innerHTML=type==='side'?'<span>'+ui('class')+'</span><b>'+g.num+'</b>':'<strong>'+g.num+'</strong><span>'+ui('class')+'</span>';b.addEventListener('click',()=>changeGrade(g.num));where.append(b);}
  }
 }
 const expanded=new Set();
 function renderList(){const q=$('search').value.trim().toLowerCase(),list=activeList(),filtered=list.filter(item=>{if(!q)return true;return [item.label.en,item.label.ta,item.title?.en,item.q.en,item.q.ta,item.topic.en,item.topic.ta,item.exercise].join(' ').toLowerCase().includes(q)});
  $('sideCount').textContent=filtered.length+' '+ui('lessons');const container=$('exerciseList');container.replaceChildren();
  const groups=new Map();for(const item of filtered){const key=item.chapter+':'+item.exercise;if(!groups.has(key))groups.set(key,[]);groups.get(key).push(item)}
  const currentGroup=current.chapter+':'+current.exercise;
  for(const [key,group] of groups){const e=group[0].exercise,c=group[0].chapter;
    const details=document.createElement('details');details.className='exercise-group';details.open=q!==''||expanded.has(key)||key===currentGroup;
    const summary=document.createElement('summary');const head=document.createElement('span');head.textContent='Ch '+c+' · '+labelForGroup(e);const count=document.createElement('span');count.className='exercise-number';count.textContent=group.length;summary.append(head,count);details.append(summary);
    details.addEventListener('toggle',()=>{if(details.open)expanded.add(key);else expanded.delete(key)});
    for(const item of group){const b=document.createElement('button');b.type='button';b.className='exercise-question';b.classList.toggle('active',current.id===item.id);b.setAttribute('aria-current',current.id===item.id?'true':'false');const icon=document.createElement('span');icon.className='question-bullet '+(completed.has(item.id)?'question-done':'');icon.textContent=completed.has(item.id)?'✓':'○';const txt=document.createElement('span');txt.textContent=tr(item.label)+' · '+tr(item.title);b.append(icon,txt);b.title=tr(item.q);b.addEventListener('click',()=>selectLesson(item));details.append(b)}container.append(details);
  }
  if(!groups.size){const no=document.createElement('div');no.className='empty-search';no.textContent=ui('empty');container.append(no)}
 }
 function buildStep(s,index){const li=document.createElement('li');li.className='worked-step';const numel=document.createElement('span');numel.className='step-circle';numel.textContent=index+1;const body=document.createElement('div');const reason=document.createElement('div');reason.className='step-reason';reason.textContent=tr(s);const equation=document.createElement('div');equation.className='step-equation';equation.innerHTML=math(s.eq);body.append(reason,equation);li.append(numel,body);return li;}
 function renderSteps(){const all=current.steps||[];const stepCount=Math.min(all.length,visible);const ul=$('stepsList');ul.replaceChildren();all.slice(0,stepCount).forEach((s,i)=>ul.append(buildStep(s,i)));
  $('stepCount').textContent=ui('step')+' '+Math.min(all.length,stepCount)+' / '+all.length;
  $('answerBox').hidden=!showAnswer;$('answerText').innerHTML=math(current.answer||'');
  $('nextStep').hidden=showAnswer;$('nextStep').innerHTML=(visible<all.length?esc(ui('nextStep')):esc(ui('answer')))+' <span aria-hidden="true">→</span>';
  $('showAll').hidden=showAnswer;$('showAll').textContent=ui('showAll');
 }
 function renderText(){document.documentElement.lang=lang;document.body.classList.toggle('lang-ta',lang==='ta');document.querySelectorAll('[data-i18n]').forEach(el=>el.textContent=ui(el.dataset.i18n));$('search').placeholder=ui('search');$('classSubtitle').textContent=ui('subtitle');$('langEn').classList.toggle('active',lang==='en');$('langTa').classList.toggle('active',lang==='ta');$('langEn').setAttribute('aria-pressed',String(lang==='en'));$('langTa').setAttribute('aria-pressed',String(lang==='ta'))}
 function render(){renderText();renderGrades();const list=activeList();const n=currentIndex(),position=n+1,chapter=classes[grade].chapters[current.chapter]||current.topic;
  $('classHeading').textContent=ui('class')+' '+grade;$('classEmblem').querySelector('span').textContent=grade;
  $('crumb').textContent=ui('class')+' '+grade+' / '+tr(chapter)+' / '+labelForGroup(current.exercise);
  $('gradeTotal').textContent=list.length+' '+ui('lessons');$('questionLabel').textContent=labelForGroup(current.exercise).toUpperCase();$('itemPosition').textContent=num(position)+' / '+num(list.length);
  $('questionTitle').textContent=tr(current.topic);$('questionHead').textContent=tr(current.label);
  $('questionText').innerHTML=math(tr(current.q));$('kindBadge').textContent=ui(current.kind==='practice'?'typePractice':'typeBook');
  $('markDone').setAttribute('aria-pressed',String(completed.has(current.id)));$('markDone').innerHTML=(completed.has(current.id)?'✓ ':'○ ')+'<span>'+esc(ui(completed.has(current.id)?'learned':'markDone'))+'</span>';
  $('referenceLink').hidden=!current.source;if(current.source)$('referenceLink').href=current.source;
  $('editionNote').textContent=ui(current.kind==='practice'?'notePractice':grade===9?'noteOld':'noteBook');
  $('figureBtn').hidden=!current.diagram;
  $('pageStatus').textContent=position+' '+ui('of')+' '+list.length;$('pageFill').style.width=(position/list.length*100)+'%';
  $('previous').disabled=n===0;$('next').disabled=n===list.length-1;
  $('previous').innerHTML='← '+esc(ui('previous'));$('next').innerHTML=esc(ui('nextQuestion'))+' →';
  $('classicLink').hidden=grade!==9;
  renderSteps();renderList();
 }
 function nextStep(){if(visible<(current.steps||[]).length)visible++;else showAnswer=true;renderSteps()}
 function showFull(){visible=(current.steps||[]).length;showAnswer=true;renderSteps()}
 function openDrawer(){if(!mobile.matches){$('search').focus();return}drawerOpen=true;document.body.classList.add('drawer-open');$('browseBtn').setAttribute('aria-expanded','true');$('sidebar').inert=false;$('sidebar').setAttribute('role','dialog');$('sidebar').setAttribute('aria-modal','true');setTimeout(()=>$('search').focus({preventScroll:true}),180)}
 function closeDrawer(){if(!drawerOpen)return;drawerOpen=false;document.body.classList.remove('drawer-open');$('browseBtn').setAttribute('aria-expanded','false');$('sidebar').inert=true;$('sidebar').removeAttribute('role');$('sidebar').removeAttribute('aria-modal');$('browseBtn').focus({preventScroll:true})}
 function onBreakpoint(){if(mobile.matches){if(!drawerOpen)$('sidebar').inert=true}else{drawerOpen=false;document.body.classList.remove('drawer-open');$('sidebar').inert=false;$('sidebar').removeAttribute('role');$('sidebar').removeAttribute('aria-modal');$('browseBtn').setAttribute('aria-expanded','false')}}
 function showDiagram(){if(!current.diagram)return;let svg='';if(current.diagram&&typeof current.diagram==='object'){svg=window.TriggleDraw.drawClassic({demo:current.diagram,ref:tr(current.label),title:tr(current.title)})}else{svg=window.TriggleDraw.drawSimple(current.diagram)}$('diagramContent').innerHTML=svg;$('visualTitle').textContent=tr(current.title);$('diagramCaption').textContent=lang==='ta'?'இந்தப் படம் புரிதலுக்கானது; அளவுப்படி வரையப்படாமல் இருக்கலாம்.':'This is an explanatory illustration, not necessarily drawn to scale.';$('figureDialog').showModal()}
 $('nextStep').onclick=nextStep;$('showAll').onclick=showFull;
 $('previous').onclick=()=>navMove(-1);$('next').onclick=()=>navMove(1);
 $('markDone').onclick=()=>{if(completed.has(current.id))completed.delete(current.id);else completed.add(current.id);store('triggle.learned.v119',[...completed]);render()};
 $('browseBtn').onclick=()=>drawerOpen?closeDrawer():openDrawer();$('closeSidebar').onclick=closeDrawer;$('backdrop').onclick=closeDrawer;
 $('search').oninput=renderList;
 $('figureBtn').onclick=showDiagram;$('closeDiagram').onclick=()=>$('figureDialog').close();
 $('figureDialog').addEventListener('click',ev=>{if(ev.target===$('figureDialog'))$('figureDialog').close()});
 $('langEn').onclick=()=>changeLanguage('en');$('langTa').onclick=()=>changeLanguage('ta');
 function changeLanguage(v){lang=v;try{localStorage.setItem('triggle-language',v)}catch{}render()}
 window.addEventListener('keydown',e=>{
  if(e.key==='Escape'&&drawerOpen){closeDrawer();return}
  if(e.key==='/'&&!e.ctrlKey&&!e.metaKey&&e.target.tagName!=='INPUT'&&e.target.tagName!=='TEXTAREA'){e.preventDefault();openDrawer();$('search').focus();return}
  if(drawerOpen&&e.key==='Tab'){const focusable=[...$('sidebar').querySelectorAll('button:not([disabled]),input:not([disabled]),a[href],summary')].filter(el=>el.getClientRects().length);if(focusable.length){const first=focusable[0],last=focusable.at(-1);if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus()}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus()}}}
  if(e.target.matches('input,textarea,select,button')||$('figureDialog').open||drawerOpen||e.altKey||e.metaKey||e.ctrlKey)return;
  if(e.key==='ArrowRight'){e.preventDefault();navMove(1)}else if(e.key==='ArrowLeft'){e.preventDefault();navMove(-1)}
 });
 window.addEventListener('popstate',()=>{const p=new URL(location.href).searchParams,g=Number(p.get('class'));grade=classes[g]?g:9;current=classes[grade].items.find(x=>x.id===p.get('question'))||classes[grade].items[0];visible=1;showAnswer=false;$('search').value='';render();closeDrawer()});
 mobile.addEventListener('change',onBreakpoint);onBreakpoint();remember();updateUrl(true);render();
})();
