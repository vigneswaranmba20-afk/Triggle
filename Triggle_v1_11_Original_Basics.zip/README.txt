Triggle v1.16: Mobile textbook answers link is displayed as text on a distinct navigation row, in English and Tamil. All other features preserved. © 2026 VIGNESWARAN E R
