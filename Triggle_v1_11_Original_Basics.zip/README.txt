Triggle v1.12 • English / தமிழ்

Open index.html (solutions) or playground.html (full original Basics).

Improvements:
• Mathematical square of an entire parenthesized fraction uses native MathML for larger parentheses and correctly placed exponent 2.
• Full bilingual original prompts and explanations for all 44 CURRENT entries. Mathematical working remains the same in both languages.
• Figures optional (View figure), not dominating the question screen.
• Answer appears only after the LAST step; never repeats on earlier step pages.
• One-screen layouts where possible; long proofs use Next steps, without dropping any steps.
• Saved language choice; print/download solutions from question picker in selected language.
• Original Playground is preserved, including Triangle Lab, Circle Magic, Wave Party, Kite Rescue, Star Quest.
• Service worker cache bumped to v1.12 for GitHub Pages updates.

Limitations: older SCERT reference edition and only the 44 prior entries, not a verified complete 2026–27 syllabus. The original Basics now also offers an EN/தமிழ் switch for its three concept labs, kite adventure, quiz and key navigation. Some labels printed inside SVG artwork remain English.

© 2026 VIGNESWARAN E R for original Triggle materials.
