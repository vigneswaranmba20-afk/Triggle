TRIGGLE — Visual Mathematics v1.19 (Classes 9–12)

BROWSE ONLINE
index.html             New all-class learning center and homepage
playground.html        Five original interactive Basics activities
class9-classic.html    Preserved previous Class 9 textbook interface
grades.html            Redirects previous Classes 10–12 bookmarks
grades-legacy.html     Archived original v1.18 class page
assets/app.css         Shared adaptive navigation and layout
assets/app.js          Search, language, step reveal, deep links, progress
assets/diagrams.js     Optional visual diagrams
data/class-*.js        One question catalogue per class for easy expansion

WORKED CONTENT
Class 9:  53 entries (44 earlier-edition question entries + 9 original practice)
Class 10: 20 entries (17 book-referenced Ch.6 exercises + 3 original practice)
Class 11: 16 entries (Ch.3 book-referenced trigonometry)
Class 12: 16 entries (Ch.4 book-referenced trigonometry + original practice)
Total: 105 entries. This is NOT yet the full textbook syllabus or 2026–27 verified book.

NAVIGATION
Phone: four class shortcuts in thumb-reach bottom dock, exercise search in sliding bottom sheet.
Desktop: persistent navigation sidebar with chapter/exercise groups and keyboard shortcut /.
Every problem: question, step-by-step working, final result, optional diagram, progress marker, English/Tamil.
Use ?class=10&question=<id> for linkable lesson. Local saved progress requires no account.
No disruptive Brilliant! overlay. Fireworks are retained for each correct check in Basics.

EXTERNAL REFERENCES
Class 9 old PDF: https://cdn1.byjus.com/wp-content/uploads/2019/04/Tamilnadu-Board-Class-9-Maths-Textbook-Chapter-6-Term-II.pdf
Class 10: https://www.shaalaa.com/hin/textbook-solutions/c/samacheer-kalvi-solutions-mathematics-english-class-10-sslc-tn-board-chapter-6-trigonometry_3994
Class 11: https://www.shaalaa.com/hin/textbook-solutions/c/samacheer-kalvi-solutions-mathematics-volume-1-and-2-english-class-11-tn-board-chapter-3-trigonometry_4527
Class 12: https://www.shaalaa.com/textbook-solutions/c/samacheer-kalvi-solutions-mathematics-volume-1-and-2-english-class-12-tn-board-chapter-4-inverse-trigonometric-functions_4842

DEPLOYMENT
Upload Triggle_v1_11_Original_Basics.zip to GitHub repository root to trigger current workflow.
Do not alter this ZIP filename without updating .github/workflows/deploy.yml.
If branch-based Pages deployment overrides, switch Pages Source to GitHub Actions and rerun publish ZIP.

© 2026 VIGNESWARAN E R · All rights reserved.
