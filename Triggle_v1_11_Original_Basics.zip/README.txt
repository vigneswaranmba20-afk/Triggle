TRIGGLE — TWO-PAGE EDITION (v1.11)

This package intentionally contains TWO pages:
  index.html       -> Class 9 worked solutions and exercise navigation
  playground.html  -> Restored original five-activity interactive playground

Navigation:
  Tap "Learn basics" in index.html to open playground.html.
  Tap "Class 9 solutions" in playground.html to return.

GITHUB PAGES / CLOUDFLARE:
  Upload index.html and playground.html to the SAME website directory.
  Upload manifest.webmanifest, service-worker.js and the icons folder too.
  A local single HTML file by itself cannot open the other page; keep both together.
  If an older PWA appears, reload or reinstall after publishing so the new cache is used.

The original playground includes Triangle Lab, Circle Magic, Wave Party,
Kite Rescue and Star Quest, unchanged apart from an added back link.

Worked-solution contents follow the existing older TN SCERT reference edition,
not a verified 2026–27 textbook. Questions are paraphrased.

Copyright © 2026 VIGNESWARAN E R — original Triggle code and learning content.
