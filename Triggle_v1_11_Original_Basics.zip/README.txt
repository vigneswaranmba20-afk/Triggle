Triggle v1.18 — Foundations for Classes 9–12

- Fixes: Circle Magic clipping on short mobile screens; repeated success fireworks in Kite Rescue; Star Quest celebrations.
- Class 9: preserves 44 existing solution entries and English/Tamil navigation.
- Classes 10–12: grades.html contains initial full-step bilingual starter lessons, with chapter labels and optional illustrations.
- Class 10: first two questions modeled on TN Board Chapter 6 Ex 6.1 Q1(i) and Ex 6.2 Q1.
- Classes 11 & 12: ORIGINAL practice questions, not claimed to be verbatim textbook exercises.
- NOT a complete or 2026–27-verified set of book exercise answers.
- Sources: Class10 https://www.shaalaa.com/hin/textbook-solutions/c/samacheer-kalvi-solutions-mathematics-english-class-10-sslc-tn-board-chapter-6-trigonometry_3994 ; Class11 https://ndl.iitkgp.ac.in/se_document/tn_school_board/12345678_tnbrd/16685 ; Class12 https://cdn1.byjus.com/wp-content/uploads/2019/04/Tamilnadu-Board-Class-12-Maths-Chapter-4.pdf
- GitHub deployment: use the separately named same-filename ZIP, as in previous releases.
© 2026 VIGNESWARAN E R. All rights reserved for original Triggle content.
