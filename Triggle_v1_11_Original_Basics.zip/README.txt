Triggle v1.15 minor usability fixes
- Use / in learning formulas instead of ÷
- Clearer Textbook answers button in Basics
- Improved Kite Rescue bottom spacing on mobile

Triggle v1.12 • English / தமிழ்

Open index.html (solutions) or playground.html (full original Basics).

Improvements:
• Mathematical square of an entire parenthesized fraction uses native MathML for larger parentheses and correctly placed exponent 2.
• Full bilingual original prompts and explanations for all 44 CURRENT entries. Mathematical working remains the same in both languages.
• Figures optional (View figure), not dominating the question screen.
• Answer appears only after the LAST step; never repeats on earlier step pages.
• One-screen layouts where possible; long proofs use Next steps, without dropping any steps.
• Saved language choice; print/download solutions from question picker in selected language.
• Original Playground is preserved, including Triangle Lab, Circle Magic, Wave Party, Kite Rescue, Star Quest.
• Service worker cache bumped to v1.12 for GitHub Pages updates.

Limitations: older SCERT reference edition and only the 44 prior entries, not a verified complete 2026–27 syllabus. The original Basics now also offers an EN/தமிழ் switch for its three concept labs, kite adventure, quiz and key navigation. Some labels printed inside SVG artwork remain English.

© 2026 VIGNESWARAN E R for original Triggle materials.

TRIGGLE v1.13 MOBILE ONE-VIEW UPDATE
- The Basics page now puts the active diagram, slider and live numbers on the same visible phone screen.
- Compact tabs switch activities. The large introductory banner is hidden on narrow screens only.
- On very short phones, only the control panel may scroll; the diagram remains in view.
- Mathematics, bilingual text, games and Class 9 solutions are preserved from v1.12.
- v1.13 cache prevents an older installed PWA from keeping the previous CSS.


TRIGGLE v1.14 - MATHEMATICAL QUESTION DISPLAY FIX
- Fixed malformed superscript HTML inside fraction accessibility attributes (leaked 2"> etc).
- Corrected Exercise 6.1 Q5 and Exercise 6.5 Q4 display in English and Tamil.
- Exercise 6.5 Q4 now places its expression on a separate readable math line.
- Preserved separate Basics page and existing one-screen mobile design.
- Service worker cache version incremented to v1.14.
- Exercises still reference the older SCERT edition and need full editorial verification.
