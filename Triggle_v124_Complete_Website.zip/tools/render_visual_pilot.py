"""Generate an original, mathematically faithful VISUAL-ONLY pilot video.
This is not the user's previously produced narrated lesson and must not be presented as one.
No paid APIs, no external downloads, no subtitles. Make narration in the future by replacing the MP4.
"""
from PIL import Image, ImageDraw, ImageFont
from pathlib import Path
import math, subprocess, time
W,H=720,1080
FPS=12
SECS=72
ROOT=Path(__file__).resolve().parent.parent
out=ROOT/'videos/triggle-class12-ex4-1-q1-ii-visual-preview.mp4'
poster=ROOT/'videos/posters/triggle-class12-ex4-1-q1-ii.webp'
out.parent.mkdir(parents=True,exist_ok=True);poster.parent.mkdir(parents=True,exist_ok=True)
IVORY=(250,249,246); VIOLET=(59,46,107); PURPLE=(118,89,206); GOLD=(228,171,89)
BLUE=(75,135,223);PINK=(222,87,139);MUTED=(112,107,131);GRAY=(191,190,209)
F='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
FB='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
fonts={('r',z):ImageFont.truetype(F,z) for z in (14,16,18,19,20,21,22,23,24,26,28,30,34,38,43,48,52)}
fonts.update({('b',z):ImageFont.truetype(FB,z) for z in (14,16,18,19,20,21,22,23,24,26,28,30,34,38,43,48,52)})
def ft(s=24,b=False):return fonts[('b' if b else 'r',s)]
def text(d,xy,s,sz=24,col=VIOLET,b=False,anchor=None):
 d.text(xy,s,font=ft(sz,b),fill=col,anchor=anchor,stroke_width=0)
def bar(d,x,y,w,h,col,r=14):d.rounded_rectangle((x,y,x+w,y+h),radius=r,fill=col)
def line(d,coords,col,th=3):d.line(coords,fill=col,width=th,joint='curve')
def polar(cx,cy,r,a):return (cx+r*math.cos(a),cy-r*math.sin(a))
def eased(p): p=max(0,min(1,p));return p*p*(3-2*p)
def wrap(d,s,start_x,y,chars=36,sz=25,color=MUTED,spacing=40,b=False):
 words=s.split(' '); line='';
 for word in words:
  proposal=(line+' '+word).strip()
  if len(proposal)>chars and line:
   text(d,(start_x,y),line,sz,color,b);y+=spacing;line=word
  else:line=proposal
 if line:text(d,(start_x,y),line,sz,color,b)
 return y+spacing

def draw_circle(d,theta=-math.pi/2, highlight=False,show_axes=True,trail=0,annotation=True):
 cx,cy,r=360,495,191
 d.ellipse((cx-r-1,cy-r-1,cx+r+1,cy+r+1),fill=(248,244,255),outline=(181,161,232),width=6)
 if show_axes:
  line(d,[(cx-r-42,cy),(cx+r+42,cy)],(148,147,167),3)
  line(d,[(cx,cy+r+33),(cx,cy-r-33)],(148,147,167),3)
  text(d,(cx+r+33,cy-21),'x',24,MUTED,b=True)
  text(d,(cx+13,cy-r-34),'y',24,MUTED,b=True)
  text(d,(cx+r+8,cy+18),'+1',18,MUTED)
  text(d,(cx-r-8,cy+18),'−1',18,MUTED,anchor='ra')
  text(d,(cx+12,cy-r+24),'+1',18,MUTED)
  text(d,(cx+12,cy+r-5),'−1',18,MUTED)
 if trail:
  max_angle=theta
  steps=max(3,int(abs(trail)*88));a0=theta-trail
  pts=[polar(cx,cy,r,a0+trail*i/steps) for i in range(steps+1)]
  line(d,pts,PINK,6)
 px,py=polar(cx,cy,r,theta)
 if show_axes:
  line(d,[(cx,cy),(px,cy)],BLUE,10)
  line(d,[(px,cy),(px,py)],PINK,10)
 line(d,[(cx,cy),(px,py)],GOLD,7)
 d.ellipse((px-16,py-16,px+16,py+16),fill=GOLD,outline=IVORY,width=5)
 d.ellipse((cx-5,cy-5,cx+5,cy+5),fill=VIOLET)
 if annotation:
  text(d,(47,728),'PINK = sine (vertical)',21,PINK,b=True)
  text(d,(47,764),'BLUE = cosine (horizontal)',21,BLUE,b=True)
 return px,py

def stage(t):
 if t<10:return 0
 if t<22:return 1
 if t<33:return 2
 if t<47:return 3
 if t<57:return 4
 if t<68:return 5
 return 6

def frame(t):
 i=stage(t)
 im=Image.new('RGB',(W,H),IVORY);d=ImageDraw.Draw(im)
 d.rectangle((0,0,W,15),fill=VIOLET)
 d.rectangle((0,0,W*min(1,t/SECS),15),fill=PURPLE)
 text(d,(40,42),'✦  TRIGGLE',30,VIOLET,True)
 text(d,(40,93),'CLASS 12  ·  EXERCISE 4.1  ·  1(ii)',18,MUTED,True)
 titles=['What are we solving?','Meet sine on a circle','A radian is an angle','One turn adds 2π','Choose allowed rotations','Verify on the sine graph','Every answer checks out']
 text(d,(40,145),titles[i],34,VIOLET,True)
 bar(d,32,205,656,660,(255,255,255),20)
 d.rounded_rectangle((32,205,688,865),radius=20,outline=(233,229,239),width=2)
 text(d,(57,230),'sin x = −1',38,VIOLET,True)
 text(d,(57,283),'−3π ≤ x ≤ 3π',28,MUTED,True)

 if i<5:
  theta=-math.pi/2
  trail=0
  if i==0: theta=-math.pi/2*eased((t-1)/7)
  if i==1: theta=-math.pi/2*eased((t-10)/5)
  if i==2:
   theta=2*math.pi*eased((t-22)/9)
   trail=theta if theta else 0
  if i==3:
   seq=[-1,0,1]
   j=min(2,int((t-33)/4.67))
   k=seq[max(0,j)]
   local=(t-33-j*4.67)/4.67
   total=-math.pi/2+2*math.pi*k
   theta=total*eased(local)
   trail=total*eased(local)
  if i==4: theta=-math.pi/2
  draw_circle(d,theta,trail=trail,annotation=False)
  if i==0:
   text(d,(63,729),'The pink height is the sine value.',23,PINK,True)
   text(d,(63,770),'We need points where that height is −1.',21,MUTED)
  elif i==1:
   if t<17:
    text(d,(63,728),'Move clockwise from the positive x-axis.',21,VIOLET,True)
    text(d,(63,770),'Watch the pink height decrease to −1.',20,MUTED)
   else:
    text(d,(63,728),'At the bottom: (cos x, sin x) = (0, −1)',21,VIOLET,True)
    text(d,(63,770),'That angle is −π/2 (clockwise quarter-turn).',20,MUTED)
  elif i==2:
   text(d,(63,725),'π radians = half a turn = 180°',22,VIOLET,True)
   text(d,(63,771),'2π radians = one full turn = 360°',21,PURPLE,True)
  elif i==3:
   j=min(2,int((t-33)/4.67));k=[-1,0,1][max(0,j)]
   angles={-1:'−5π/2',0:'−π/2',1:'3π/2'}
   bar(d,55,710,610,104,(240,235,255),15)
   text(d,(73,727),'x = −π/2 + 2kπ',28,VIOLET,True)
   text(d,(73,774),f'k = {k:+d}    →    x = {angles[k]}',24,PURPLE,True)
  else:
   text(d,(55,706),'k = −1   →   x = −5π/2',22,VIOLET,True)
   text(d,(55,742),'k =  0    →   x = −π/2',22,VIOLET,True)
   text(d,(55,778),'k = +1   →   x = 3π/2',22,VIOLET,True)
   text(d,(55,817),'All three lie between −3π and 3π.',18,PURPLE,True)
 else:
  x0,x1,y0,y1=80,662,360,735
  xmin,xmax=-3*math.pi,3*math.pi
  def xx(a):return x0+(a-xmin)/(xmax-xmin)*(x1-x0)
  def yy(a):return y0+(1-a)/2*(y1-y0)
  line(d,[(x0,y0+(y1-y0)/2),(x1,y0+(y1-y0)/2)],GRAY,2)
  line(d,[(xx(0),y0),(xx(0),y1)],GRAY,2)
  d.line([(x0,yy(-1)),(x1,yy(-1))],fill=(232,185,205),width=3)
  pts=[(xx(xmin+(xmax-xmin)*j/430),yy(math.sin(xmin+(xmax-xmin)*j/430))) for j in range(431)]
  line(d,pts,PURPLE,5)
  text(d,(55,326),'y = sin x',24,VIOLET,True)
  text(d,(65,yy(-1)-28),'y = −1',18,PINK,True)
  text(d,(xx(-3*math.pi),y1+11),'−3π',18,MUTED,anchor='mt')
  text(d,(xx(0),y1+11),'0',18,MUTED,anchor='mt')
  text(d,(xx(3*math.pi),y1+11),'3π',18,MUTED,anchor='mt')
  vals=[(-5*math.pi/2,'−5π/2'),(-math.pi/2,'−π/2'),(3*math.pi/2,'3π/2')]
  visible=3 if i==6 else min(3,1+int((t-57)//3))
  for idx,(val,label) in enumerate(vals[:visible]):
   a,b=xx(val),yy(-1)
   d.ellipse((a-11,b-11,a+11,b+11),fill=PINK,outline=IVORY,width=3)
   text(d,(a,b-47),label,18,VIOLET,True,anchor='mm')
  if i==6:
   text(d,(49,817),'Each marked angle gives sin x = −1.',19,VIOLET,True)
  else:
   text(d,(50,822),'The graph touches −1 at three angles.',19,MUTED)

 bar(d,32,887,656,138,(241,238,250),17)
 msg={
 0:['FIND ALL SOLUTIONS','Read the equation AND its allowed interval.'],
 1:['WHY IS SINE NEGATIVE?','Below the x-axis, sine is negative.'],
 2:['WHY 2π?','The circle has 2π radians in one full turn.'],
 3:['REPEATED FULL ROTATIONS','x = −π/2 + 2kπ, where k is an integer.'],
 4:['INTERVAL FILTER','k = −2 or +2 would fall outside the interval.'],
 5:['A VISUAL CHECK','The three marked points have sine value −1.'],
 6:['FINAL ANSWERS','x = −5π/2, −π/2, 3π/2']
 }[i]
 text(d,(55,901),msg[0],20,VIOLET,True)
 wrap(d,msg[1],55,946,chars=49,sz=21,color=MUTED,spacing=29)
 text(d,(345,1045),'VISUAL-ONLY PILOT  ·  NARRATION PENDING',14,MUTED,b=True,anchor='mm') if False else None
 return im

def main():
 cmd=['ffmpeg','-y','-hide_banner','-loglevel','error','-f','rawvideo','-pix_fmt','rgb24','-s',f'{W}x{H}','-r',str(FPS),'-i','pipe:0','-an','-c:v','libx264','-pix_fmt','yuv420p','-crf','26','-preset','veryfast','-movflags','+faststart','-r',str(FPS),str(out)]
 p=subprocess.Popen(cmd,stdin=subprocess.PIPE,stderr=subprocess.PIPE)
 start=time.time()
 try:
  for f in range(SECS*FPS):
   im=frame(f/FPS)
   p.stdin.write(im.tobytes())
   if f==19*FPS: im.save(poster,'WEBP',quality=85)
   if f%(12*FPS)==0: print('encoded frames',f,'/',SECS*FPS,flush=True)
  p.stdin.close()
  err=p.stderr.read().decode('utf-8',errors='replace')
  p.wait()
  if p.returncode:raise RuntimeError(err)
 except Exception:
  p.kill();raise
 print('DONE',out,out.stat().st_size,'bytes; duration',SECS,'seconds','elapsed',round(time.time()-start,1),flush=True)

if __name__=='__main__': main()
