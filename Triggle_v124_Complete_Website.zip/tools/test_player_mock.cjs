// Node-only controller smoke test. Not a substitute for testing Android Chrome.
const fs=require('fs'),vm=require('vm'),path=require('path'),assert=require('assert');
const root=path.resolve(__dirname,'..');
const manifest=JSON.parse(fs.readFileSync(path.join(root,'data/video-lessons.json'),'utf8'));
const listeners=new Map(),els=new Map();
class FakeEl{
  constructor(id){this.id=id;this.hidden=id==='visualLessonAction';this.open=false;this.textContent='';this.playbackRate=1;this.src='';this.href='';this.dataset={};this.events=new Map();this.style={};this.isConnected=true;}
  addEventListener(event,cb){this.events.set(event,cb)}
  dispatch(event,props={}){let cb=this.events.get(event);if(cb)cb({target:this,preventDefault(){},...props});}
  setAttribute(k,v){this[k]=v}
  removeAttribute(k){this[k]=''}
  showModal(){this.open=true}
  close(){this.open=false}
  pause(){this.paused=true}
  load(){this.loaded=(this.loaded||0)+1}
  focus(){this.focused=true}
  querySelector(){return this}
}
function $(id){if(!els.has(id))els.set(id,new FakeEl(id));return els.get(id)}
const location=new URL('https://example.test/Triggle/index.html?class=12&question=c12-4-4-1-2');
const win={TRIGGLE_CLASSES:{12:{items:[{id:'c12-4-4-1-2',q:{en:'Find x in −3π ≤ x ≤ 3π for which sin x = −1.'}}]}},addEventListener:(k,cb)=>{let arr=listeners.get(k)||[];arr.push(cb);listeners.set(k,arr);},dispatchEvent(e){for(const cb of listeners.get(e.type)||[])cb(e)},scrollTo(){},scrollY:310};
const history={state:{},pushState(s){this.state=s;},back(){this.state={};let stopped=false;let e={stopImmediatePropagation(){stopped=true}};for(const cb of listeners.get('popstate')||[]){if(stopped)break;cb(e)}}};
const document={baseURI:location.href,getElementById:$,activeElement:$('visualLessonBtn')};
const sandbox={window:win,document,location,history,HTMLElement:FakeEl,URL,console,fetch:async()=>({ok:true,json:async()=>manifest}),localStorage:{getItem(){return 'en'}},requestAnimationFrame:f=>f()};
vm.runInNewContext(fs.readFileSync(path.join(root,'assets/visual-lessons.js'),'utf8'),sandbox,{filename:'visual-lessons.js'});
setTimeout(()=>{
 try{
  assert.equal($('visualLessonAction').hidden,false,'video question appears');
  $('visualLessonBtn').dispatch('click');
  assert.equal($('visualLessonDialog').open,true);
  assert.ok($('vlVideo').src.endsWith('visual-preview.mp4'));
  assert.equal($('vlVideo').paused,true,'does not autoplay');
  assert.ok($('vlDownload').href.endsWith('visual-preview.mp4'));
  assert.ok($('vlDownload').download.endsWith('.mp4'));
  $('vlClose').dispatch('click');
  assert.equal($('visualLessonDialog').open,false,'close returns to question');
  win.dispatchEvent({type:'triggle:lessonchange',detail:{lang:'ta',grade:12,item:win.TRIGGLE_CLASSES[12].items[0]}});
  assert.equal($('visualLessonAction').hidden,false,'Tamil labels enabled');
  assert.ok($('visualLessonBtnLabel').textContent.includes('காட்சி'));
  win.dispatchEvent({type:'triggle:lessonchange',detail:{lang:'en',grade:9,item:{id:'other',q:{en:'other'}}}});
  assert.equal($('visualLessonAction').hidden,true,'unavailable lessons hide button');
  console.log('PASS: manifest gating, open, MP4 link, download, no autoplay, Back/close, Tamil, unavailable lessons');
 }catch(e){console.error('FAIL:',e.stack);process.exitCode=1}
},0);
