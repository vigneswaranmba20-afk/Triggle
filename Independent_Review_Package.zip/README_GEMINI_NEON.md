# TRACE MathGuard V1.4c Independent Review Package (Gemini Neon)

- Pinned Git Commit: `1300f61`
- Run Unit & Regression Tests: `PYTHONPATH=site/tools python3 -m pytest site/tools/mathguard/tests -v`
- Run V1.4c Full Runner: `PYTHONPATH=site/tools python3 -m mathguard.v1_4c_runner`
- Review `blind_review_cases.json` against source textbooks independently.
